package javaNameConvention;

public class NameConvention {
	int enBuyukSayi;
	
	public NameConvention() 
	{
		
	}


	void getAllByCategory(int categoryId) 
	{
		int enKucukSayi;
		
	}


	

}

